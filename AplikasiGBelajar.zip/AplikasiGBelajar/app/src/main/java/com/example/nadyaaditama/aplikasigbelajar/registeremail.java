package com.example.nadyaaditama.aplikasigbelajar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class registeremail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registeremail);
    }
}
